// src/constants/products.js
// 카테고리/상태 상수
export const CATEGORIES = ['밀키트', '전자제품', '화장품', '무형자산']
export const STATUS = ['판매중', '품절']