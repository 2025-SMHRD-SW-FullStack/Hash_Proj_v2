import React from 'react'

const FeedbackPage = () => {
  return (
    <div>FeedbackPage</div>
  )
}

export default FeedbackPage