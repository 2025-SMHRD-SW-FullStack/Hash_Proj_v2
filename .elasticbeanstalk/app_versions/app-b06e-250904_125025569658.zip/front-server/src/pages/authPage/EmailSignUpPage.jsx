import React from 'react'
import EmailSignUpForm from '../../components/auth/EmailSignUpForm'

const EmailSignUp = () => {
  return (
    <>
      <EmailSignUpForm />
    </>
  )
}

export default EmailSignUp
