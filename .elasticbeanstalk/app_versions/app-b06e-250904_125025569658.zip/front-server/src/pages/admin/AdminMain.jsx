import React from 'react'



const card = 'rounded-xl border bg-white p-4 shadow-sm'

export default function AdminMain() {
    return (
        <div>
           
        </div>
    )
}