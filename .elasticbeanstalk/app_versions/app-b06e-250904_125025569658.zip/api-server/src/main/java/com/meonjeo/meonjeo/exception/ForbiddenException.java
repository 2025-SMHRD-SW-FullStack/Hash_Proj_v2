package com.meonjeo.meonjeo.exception;

public class ForbiddenException extends RuntimeException { public ForbiddenException(String m){ super(m); } }
