package com.meonjeo.meonjeo.feedback;

public interface FeedbackRewardPolicy {
    int feedbackPointOf(Long orderItemId);
}
