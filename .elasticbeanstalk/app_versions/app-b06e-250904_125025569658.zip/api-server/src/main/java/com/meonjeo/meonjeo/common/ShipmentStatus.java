package com.meonjeo.meonjeo.common;
public enum ShipmentStatus { READY, IN_TRANSIT, DELIVERED }
