package com.meonjeo.meonjeo.seller;
public enum SellerStatus { PENDING, APPROVED, REJECTED }
