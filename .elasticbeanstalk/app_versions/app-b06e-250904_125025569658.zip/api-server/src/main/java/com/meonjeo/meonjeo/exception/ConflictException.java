package com.meonjeo.meonjeo.exception;
public class ConflictException extends RuntimeException {
    public ConflictException(String m){ super(m); }
}
