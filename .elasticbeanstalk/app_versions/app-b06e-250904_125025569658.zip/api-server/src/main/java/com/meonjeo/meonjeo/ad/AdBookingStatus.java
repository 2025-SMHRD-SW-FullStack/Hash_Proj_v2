package com.meonjeo.meonjeo.ad;
public enum AdBookingStatus { RESERVED_UNPAID, RESERVED_PAID, ACTIVE, COMPLETED, CANCELLED }
