package com.meonjeo.meonjeo.survey;
public enum QuestionType { SCALE_1_5, CHOICE_ONE }
