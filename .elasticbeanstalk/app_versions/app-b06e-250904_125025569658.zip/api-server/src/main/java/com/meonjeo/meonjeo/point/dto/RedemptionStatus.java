package com.meonjeo.meonjeo.point.dto;

public enum RedemptionStatus { REQUESTED, APPROVED, REJECTED }
