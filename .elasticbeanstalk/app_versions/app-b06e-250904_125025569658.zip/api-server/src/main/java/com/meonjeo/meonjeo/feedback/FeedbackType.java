package com.meonjeo.meonjeo.feedback;
public enum FeedbackType { MANUAL, AI }
