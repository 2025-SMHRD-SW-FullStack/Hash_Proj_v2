package com.meonjeo.meonjeo.shipment;

public enum ShipmentType {
    ORDER, EXCHANGE
}
