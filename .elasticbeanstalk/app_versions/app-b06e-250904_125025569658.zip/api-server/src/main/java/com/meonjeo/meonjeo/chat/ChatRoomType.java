package com.meonjeo.meonjeo.chat;
public enum ChatRoomType { USER_SELLER }
