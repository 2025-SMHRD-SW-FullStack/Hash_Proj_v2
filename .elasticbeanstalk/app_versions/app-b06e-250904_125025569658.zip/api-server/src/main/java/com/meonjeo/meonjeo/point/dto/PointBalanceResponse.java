package com.meonjeo.meonjeo.point.dto;

public record PointBalanceResponse(int balance) {}