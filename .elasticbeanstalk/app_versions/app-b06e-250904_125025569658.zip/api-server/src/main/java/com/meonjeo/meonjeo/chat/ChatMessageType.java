package com.meonjeo.meonjeo.chat;
public enum ChatMessageType { TEXT, IMAGE, SYSTEM }
