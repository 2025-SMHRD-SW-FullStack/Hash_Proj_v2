package com.meonjeo.meonjeo.exception;

public enum ReviewErrorCode {
    REVIEW_NOT_FOUND,
    MAX_REGEN_EXCEEDED,
    INVALID_STATE,
    CONFLICT
}
