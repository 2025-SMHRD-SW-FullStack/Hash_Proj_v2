package com.meonjeo.meonjeo.exception;

public class EmailTokenException extends RuntimeException {
    public EmailTokenException(String message) {
        super(message);
    }
}
