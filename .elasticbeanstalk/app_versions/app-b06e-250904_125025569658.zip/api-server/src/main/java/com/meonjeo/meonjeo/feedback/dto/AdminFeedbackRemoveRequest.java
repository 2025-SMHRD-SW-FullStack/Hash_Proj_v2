package com.meonjeo.meonjeo.feedback.dto;

public record AdminFeedbackRemoveRequest(String reason) {}
