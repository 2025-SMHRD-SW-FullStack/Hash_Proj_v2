package com.meonjeo.meonjeo.exception;


public class InsufficientPointBalanceException extends RuntimeException {
    public InsufficientPointBalanceException(String message) { super(message); }
}
