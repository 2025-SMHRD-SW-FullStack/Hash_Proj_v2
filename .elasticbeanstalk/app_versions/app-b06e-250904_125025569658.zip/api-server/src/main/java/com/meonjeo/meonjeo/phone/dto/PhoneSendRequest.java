package com.meonjeo.meonjeo.phone.dto;
import lombok.Getter; import lombok.Setter;
@Getter @Setter public class PhoneSendRequest { private String phoneNumber; }
