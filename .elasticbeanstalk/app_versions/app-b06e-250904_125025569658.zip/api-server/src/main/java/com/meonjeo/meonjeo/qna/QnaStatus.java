package com.meonjeo.meonjeo.qna;

public enum QnaStatus {
    WAITING,   // 답변 대기중
    ANSWERED,  // 답변 완료
    CLOSED     // 종료됨
}
