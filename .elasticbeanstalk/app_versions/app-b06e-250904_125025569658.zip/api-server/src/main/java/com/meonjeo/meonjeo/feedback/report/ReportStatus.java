package com.meonjeo.meonjeo.feedback.report;
public enum ReportStatus { PENDING, APPROVED, REJECTED }
