package com.meonjeo.meonjeo.ad;
public enum AdSlotType { MAIN_ROLLING, MAIN_SIDE, CATEGORY_TOP, ORDER_COMPLETE }
